
package Entities;

import java.util.List;

public class Entidad 
{
    private String tabla;
    private String nombre;

    public void setTabla(String tabla) {
        this.tabla = tabla;
        //System.out.println(tabla);
    }
    public String getTabla() {
        return tabla;
    }

        public void setNombre(String nombre) {
            this.nombre = nombre;
            //System.out.println(nombre);
        }
        public String getNombre() {
            return nombre;
        }
}
