
package Builder;

import Entities.Entidad;
import Entities.Modelo;
import java.beans.Statement;
import java.sql.*;

public class ModeloBuilder 
{
    
    private static final String url = "jdbc:mysql://localhost:3306/academico?characterEncoding=latin1"; //Conexión por URL y localhost de la base de datos
    private static final String driver = "com.mysql.jdbc.Driver"; //Conexión por Driver
    private static final String user = "root"; //Usuario de la Base de Datos MYSQL
    private static final String password = "root"; //Clave de la Base de Datos MYSQL
    public static Connection connection;
    private ResultSet rs; //Para almacenar el resultado de la consulta
    private Statement statement; //Para ejecutar sentencias SQL y enviarlas a las Bases de Datos MYSQL
    private String error;
    
    public ModeloBuilder()// Carga el driver
    {
        this.rs = null;
        this.error = null;
        
        try
        {
           Class.forName(this.driver); 
        }
        catch(ClassNotFoundException e)
        {
            System.out.println("Error al cargar el driver de la base de datos"); //Muestra un error de carga del driver
        }
    }
    
    public Connection makeConnection() // Crea la conexion
    {
        try
        {
           this.connection = DriverManager.getConnection(this.url, this.user, this.password);
        }
        catch(SQLException e)
        {
            return null;
        }
        return this.connection;
    }
   
    public static Modelo cargarModelo()
    {
      
        Modelo m = new Modelo();
      //  m.setNombre("TABLE_CAT");
        try 
            {
                Class.forName(driver);
                
                ModeloBuilder.connection = DriverManager.getConnection(url, user, password); //Realiza la conexión a la Base de Datos con la URL, usuario y password anteriormente registrados
                ModeloBuilder database = new ModeloBuilder();
                
                database.makeConnection();
                DatabaseMetaData metadata = connection.getMetaData(); 
                ResultSet resultSet2 = metadata.getColumns(null, null, null, null);
                
                String nameBD = "";
                String vtablas ="";
                String vcolumnas ="";
                String vcampos ="";
                
                    while (resultSet2.next()) 
                        {
                        Entidad e = new Entidad();
                        nameBD = resultSet2.getString("TABLE_CAT");// retorna el nombre de la BD
                        vtablas = resultSet2.getString("TABLE_NAME");//retorna el nombre de todas las tablas de la BD
                        vcolumnas = resultSet2.getString("COLUMN_NAME");// retorna los campos de todas las tablas de la BD
                        vcampos = resultSet2.getString("TYPE_NAME");// retorna el tipo de datos de los campos
                        String[] nombreBD = {nameBD};
                        String[] tablas = {vtablas};
                        String[] columnas = {vcolumnas}; 
                        String[] campos = {vcampos};
                            
                        //System.out.println(nameBD);
                        
                            for (String nombrebase : nombreBD)
                            {
                                e.setNombre(nombrebase);
                                m.setNombre(nombrebase);
                                m.getEntidades().add(e);
                                
                            }
                                for (String tabla : tablas)
                                {
                                    e.setTabla(tabla);
                                    m.setTabla(tabla);
                                    m.getEntidades().add(e);
                                }
                        }
            }   
        
        catch(Exception e)
        {  
        }
         return m;
    }

    public boolean closeConnection()
    {        
        try
        {
           this.connection.close();
        }
            catch(SQLException e)
            {
                return false;
            }
            return true;
    }
       
}
