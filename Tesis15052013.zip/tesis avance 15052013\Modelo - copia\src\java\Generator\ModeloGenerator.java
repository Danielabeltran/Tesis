/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Generator;


import Entities.Entidad;
import Entities.Modelo;
import Utilities.Functions;
import Utilities.Txtbuild;
import java.io.File;
import java.io.IOException;


/**
 *
 * @author daniela.beltran
 */
public class ModeloGenerator {


  public static void generarCodigo(Modelo m) throws IOException {
           
        Functions g = new Functions();
        Txtbuild t = new Txtbuild();
        String myfolder = "C:/";
	File f= new File(myfolder + m.getNombre());
        f.mkdir();
        
        for (int i=1; i<=2; i++){
                g.ldir ( f + "/build" );
                g.ldir ( f + "/business" );
                g.ldir ( f + "/controllers" );
                g.ldir ( f + "/data" );
                g.ldir ( f + "/entities" );
                g.ldir ( f + "/src" );
                g.ldir ( f + "/web" );
                g.WriterFile(t.Tbuild(), f + "/" + "build.xml");
       }

            for (Entidad e1: m.getEntidades()){
                    try{
                            String nombreClase = e1.getNombre().substring(0, 1).toUpperCase() + e1.getNombre().substring(1);
                            String tablaClase = e1.getTabla().substring(0, 1).toUpperCase() + e1.getTabla().substring(1);
                            m.getNombre();
                            m.getTabla();

                                g.WriterFile( g.NL() + g.NL() +"package " + nombreClase + ".data;" + g.NL() + g.NL() + g.NL() +
                                            "import java.util.ArrayList;" + g.NL() +
                                            "import java.util.List;" + g.NL() +
                                            "//import ..."+ g.NL() + g.NL() +
                                            "Public class " + tablaClase+ "DAO {"+ g.NL() + g.NL() +
                                            "public List<" + tablaClase+ "> getAll(){}// metodo" + g.NL() + g.NL() +
                                            "public void CREATE(" + tablaClase+ " nn){}// metodo" + g.NL() + g.NL() + 	
                                            "public void UPDATE(" + tablaClase+ " nn){}// metodo" + g.NL() + g.NL() +
                                            "public void DELETE(" + tablaClase+ " nn){}// metodo" + g.NL() + g.NL() +
                                            "public " + tablaClase+ " getById(int id){}// metodo"+ g.NL() + g.NL() +
                                            "}",
                                            f + "/data/" + tablaClase+ "DAO.java"); 
                                g.WriterFile( g.NL() + g.NL() +"package " + nombreClase + ".data;" + g.NL() + g.NL() + g.NL() +
                                            "import java.util.ArrayList;" + g.NL() +
                                            "import java.util.List;" + g.NL() +
                                            "//import ..."+ g.NL() + g.NL() +
                                            "Public class " + tablaClase+ " {"+ g.NL() + g.NL() +
                                            "public List<" + tablaClase+ "> getAll(){}// metodo" + g.NL() + g.NL() +
                                            "public void CREATE(" + tablaClase+ " nn){}// metodo" + g.NL() + g.NL() + 	
                                            "public void UPDATE(" + tablaClase+ " nn){}// metodo" + g.NL() + g.NL() +
                                            "public void DELETE(" + tablaClase+ " nn){}// metodo" + g.NL() + g.NL() +
                                            "public " + tablaClase+ " getById(int id){}// metodo"+ g.NL() + g.NL() +
                                            "}",
                                            f + "/entities/" + tablaClase+ ".java");

                        }
                    catch (Exception e){//Catch exception if any
                            System.err.println("Error: " + e.getMessage());
                    }
            }
  }
}