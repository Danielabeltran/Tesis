package Entities;

import java.util.ArrayList;
import java.util.List;

public class Modelo 
{
    private String nombre;
    private List<Entidad> entidades;
    private String tabla;
    
    public Modelo()
    {
        this.nombre = "";
        this.entidades = new ArrayList<Entidad>();
        this.tabla = "";
    }

    public String getNombre() 
    {
        return nombre;
    }

    public void setNombre(String nombre) 
    {
        this.nombre = nombre;
        //System.out.println(nombre);
    }
        public String getTabla() 
        {
            return tabla;
        }

        public void setTabla(String tabla) 
        {
            this.tabla = tabla;
            //System.out.println(tabla);
        }
    
            public List<Entidad> getEntidades() 
            {
                return entidades;
            }

            public void setEntidades(List<Entidad> entidades) 
            {
                this.entidades = entidades;
                //System.out.println(entidades);
            }
    
}
